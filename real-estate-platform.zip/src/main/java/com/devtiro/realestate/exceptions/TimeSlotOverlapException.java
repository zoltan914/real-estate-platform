package com.devtiro.realestate.exceptions;

public class TimeSlotOverlapException extends RuntimeException {
    public TimeSlotOverlapException(String message) {
        super(message);
    }

}
