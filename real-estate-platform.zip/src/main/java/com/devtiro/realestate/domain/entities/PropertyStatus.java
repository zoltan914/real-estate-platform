package com.devtiro.realestate.domain.entities;

public enum PropertyStatus {
        ACTIVE,
        UNDER_CONTRACT,
        SOLD,
        TEMPORARILY_OFF_MARKET
}
