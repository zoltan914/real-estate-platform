package com.devtiro.realestate.domain.entities;

public enum Role {
    USER,
    AGENT
}
